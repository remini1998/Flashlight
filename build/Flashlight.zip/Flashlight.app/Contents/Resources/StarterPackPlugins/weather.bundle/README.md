### Ideas
- Present more information such as highs and lows, wind-speed, etc.
- If you choose to open the site, you should directly go to [http://openweathermap.org/city/\{city code\}](http://openweathermap.org/city/2666199) instead of the search results page.
- Get an API key. OpenWeatherMap "requires" an app to have a API Key. Nate should do this? [Sign up here.](http://openweathermap.org/appid) 
- Show weather for a specific day. (Overkill?)
